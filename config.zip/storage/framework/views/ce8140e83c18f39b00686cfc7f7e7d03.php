<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="author" content="Veritas Studio Creative" />
        <?php echo $__env->yieldPushContent('meta-seo'); ?>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('front/img/favicon.ico')); ?>" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="<?php echo e(asset('front/css/styles.css')); ?>" rel="stylesheet" />
        <link href="<?php echo e(asset('front/css/custom.css')); ?>" rel="stylesheet" />
        <?php echo $__env->yieldPushContent('css'); ?>
        <link href="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    </head>
    <body>
        <!-- Responsive navbar-->
        <?php echo $__env->make('front.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <!-- Page content-->
        <?php echo $__env->yieldContent('content'); ?>

        <!-- Footer-->
        <footer class="py-3 bg-dark animate__animated animate__fadeInUp">
            <div class="container"><p class="m-0 text-center text-white">Copyright &copy; PaleoAtlas <?php echo e(date('Y')); ?></p></div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="<?php echo e(asset("front/js/scripts.js")); ?>"></script>
        <?php echo $__env->yieldPushContent('js'); ?>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
        <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
        <script>
            AOS.init({
            duration: 800,
            once: true
            });
        </script>
    </body>
</html>
<?php /**PATH D:\Coding\Laravel\paleoatlas-main\resources\views/front/layout/template.blade.php ENDPATH**/ ?>