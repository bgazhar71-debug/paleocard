<?php $__env->startSection('title', 'Artikel Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="mb-4 " data-aos="fade-down">
        <a hrdef="<?php echo e(route('my-articles.create')); ?>" class="btn btn-success">Buat Artikel Baru</a>
    </div>
    <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-lg-4 col-md-6 col-12 mb-4" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>">
            <div class="card h-100 shadow-sm border-0">
                <div class="overflow-hidden">
                    <a href="<?php echo e(route('my-articles.show', $item)); ?>">
                        <img 
                            class="card-img-top post-img rounded-4 img-fluid transition"
                            src="<?php echo e($item->img ? asset('storage/back/'.$item->img) : asset('images/no-image.png')); ?>"
                            alt="<?php echo e($item->title); ?>"
                            style="object-fit:cover; max-height:220px; width:100%; transition:transform 0.3s;"
                            onmouseover="this.style.transform='scale(1.05)'"
                            onmouseout="this.style.transform='scale(1)'"
                        />
                    </a>
                </div>
                <div class="card-body d-flex flex-column">
                    <div class="small text-muted mb-2">
                        <?php echo e($item->created_at->format('d M Y')); ?>

                        <span class="mx-1">|</span>
                        <a href="<?php echo e(url('category/'.$item->Category->slug)); ?>" class="text-decoration-none text-primary">
                            <?php echo e($item->Category->name); ?>

                        </a>
                        <span class="mx-1">|</span>
                        <?php if($item->status == 1): ?>
                            <span class="badge bg-success">Publish</span>
                        <?php else: ?>
                            <span class="badge bg-secondary">Draft</span>
                        <?php endif; ?>
                    </div>
                    <h2 class="card-title h5 mb-2">
                        <a href="<?php echo e(route('my-articles.show', $item)); ?>" class="text-decoration-none text-dark"><?php echo e($item->title); ?></a>
                    </h2>
                    <p class="card-text flex-grow-1"><?php echo e(Str::limit(strip_tags($item->desc), 120, '...')); ?></p>
                    <div class="d-flex gap-2 mt-auto">
                        <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('my-articles.show', $item)); ?>">Read more →</a>
                        <a class="btn btn-sm btn-outline-warning" href="<?php echo e(route('my-articles.edit', $item)); ?>">Edit</a>
                        <form action="<?php echo e(route('my-articles.destroy', $item)); ?>" method="POST" class="delete-article-form">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-sm btn-outline-danger">Delete</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <h3>Belum ada artikel.</h3>
    <?php endif; ?>

<?php if(session('success')): ?>
<div class="swal" data-swal="<?php echo e(session('success')); ?>" style="display:none;"></div>
<?php endif; ?>

<?php $__env->startPush('js'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script>
    $(function() {
        const swalMessage = $('.swal').data('swal');
        if (swalMessage) {
            Swal.fire({
                icon: 'success',
                title: 'Sukses',
                text: swalMessage,
                timer: 3000,
                timerProgressBar: true,
                showConfirmButton: false
            });
        }
    });

    // Optimize delete confirmation event listener
    const deleteForms = document.querySelectorAll('.delete-article-form');
    deleteForms.forEach(form => {
        form.removeEventListener('submit', handleDeleteSubmit);
        form.addEventListener('submit', handleDeleteSubmit);
    });

    function handleDeleteSubmit(e) {
        e.preventDefault();
        const form = e.target;
        Swal.fire({
            title: 'Yakin hapus artikel ini?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Ya, hapus',
            cancelButtonText: 'Batal'
        }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>
    </div>
    <div class="pagination justify-content-center my-4">
        <?php echo e($articles->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\Laravel\paleoatlas-main\resources\views/front/my-articles/index.blade.php ENDPATH**/ ?>