<?php $__env->startSection('title', 'Category ' . $category->name . ' - PaleoAtlas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="mb-4" data-aos="fade-down">
            <form action="<?php echo e(route('search')); ?>" method="post" role="search" aria-label="Search articles">
                <?php echo csrf_field(); ?>
                <div class="input-group">
                    <input class="form-control rounded-start-pill" type="text" name="keyword" placeholder="Search articles..." value="<?php echo e(old('keyword', $keyword ?? '')); ?>" aria-label="Search articles" />
                    <a href="<?php echo e(url('category/'.$category->slug)); ?>" class="btn btn-outline-secondary" title="Reset search">Reset</a>
                    <button class="btn btn-primary rounded-end-pill" id="button-search" type="submit" aria-label="Submit search">Search</button>
                </div>
            </form>
        </div>
        <div class="alert alert-info py-2">
            Showing articles with category: <b><?php echo e($category->name); ?></b>
        </div>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6 col-12 mb-4" data-aos="fade-up" data-aos-delay="<?php echo e($loop->index * 100); ?>">
                    <div class="card h-100 shadow-sm border-0">
                        <div class="overflow-hidden">
                            <a href="<?php echo e(url('p/'.$item->slug)); ?>">
                                <img 
                                    class="card-img-top post-img rounded-4 img-fluid transition"
                                    src="<?php echo e($item->img ? asset('storage/back/'.$item->img) : asset('images/no-image.png')); ?>"
                                    alt="<?php echo e($item->title); ?>"
                                    style="object-fit:cover; max-height:220px; width:100%; transition:transform 0.3s;"
                                    onmouseover="this.style.transform='scale(1.05)'"
                                    onmouseout="this.style.transform='scale(1)'"
                                />
                            </a>
                        </div>
                        <div class="card-body d-flex flex-column">
                            <div class="small text-muted mb-2">
                                <?php echo e($item->created_at->format('d M Y')); ?>

                                <span class="mx-1">|</span>
                                <a href="<?php echo e(url('category/'.$item->Category->slug)); ?>" class="text-decoration-none text-primary">
                                    <?php echo e($item->Category->name); ?>

                                </a>
                                <span class="mx-1">|</span>
                                <?php if(isset($item->user)): ?>
                                    <span class="ms-2"><i class="bi bi-person"></i> <?php echo e($item->user->name); ?></span>
                                <?php endif; ?>
                                <?php if(isset($item->comments_count)): ?>
                                    <span class="badge bg-secondary ms-2"><i class="bi bi-chat"></i> <?php echo e($item->comments_count); ?></span>
                                <?php endif; ?>
                            </div>
                            <h2 class="card-title h5 mb-2">
                                <a href="<?php echo e(url('p/'.$item->slug)); ?>" class="text-decoration-none text-dark"><?php echo e($item->title); ?></a>
                            </h2>
                            <p class="card-text flex-grow-1"><?php echo e(Str::limit(strip_tags($item->desc), 120, '...')); ?></p>
                            <a class="btn btn-sm btn-outline-primary mt-auto" href="<?php echo e(url('p/'.$item->slug)); ?>">Read more →</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h3>Not Found</h3>
            <?php endif; ?>
        </div>
        <div class="pagination justify-content-center my-4">
            <?php echo e($articles->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\Laravel\paleoatlas-main\resources\views/front/category/index.blade.php ENDPATH**/ ?>