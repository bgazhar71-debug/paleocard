<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\SideWidgetProvider::class,
];
