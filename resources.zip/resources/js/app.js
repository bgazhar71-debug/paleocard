import './bootstrap';

import '../sass/app.scss';
import * as bootstrap from 'bootstrap';