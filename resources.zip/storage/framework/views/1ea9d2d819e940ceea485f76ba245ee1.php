<nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4" style="z-index: 1100; position: relative;" data-aos="fade-down" data-aos-delay="100">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>" data-aos="fade-right" data-aos-delay="200">Paleo Atlas</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(url('/')); ?>" data-aos="fade-left" data-aos-delay="300">Home</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(url('/blog')); ?>" data-aos="fade-left" data-aos-delay="350">Blog</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(url('/articles')); ?>" data-aos="fade-left" data-aos-delay="400">Article</a></li>
                <li class="nav-item dropdown" data-aos="fade-left" data-aos-delay="450">
                    <button class="btn btn-dark dropdown-toggle text-white" data-bs-toggle="dropdown" aria-expanded="false">
                        Categories
                    </button>
                    <ul class="dropdown-menu dropdown-menu-dark">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a class="dropdown-item" href="<?php echo e(url('category/'.$item->slug)); ?>"><?php echo e($item->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo e(url('all-category')); ?>">All Categories</a></li>
                    </ul>
                </li>
                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(url('/about')); ?>" data-aos="fade-left" data-aos-delay="500">About</a></li>
                <li class="nav-item"><a class="nav-link text-white" href="<?php echo e(url('/contact')); ?>" data-aos="fade-left" data-aos-delay="550">Contact</a></li>
                <?php if(auth()->guard()->check()): ?>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle d-flex align-items-center" href="#" id="navbarProfileDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="<?php echo e(Auth::user()->profile_photo ? asset('storage/profile/' . Auth::user()->profile_photo) : asset('front/assets/img/default-profile.png')); ?>"
                        alt="Profile" class="rounded-circle" width="32" height="32">
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-dark" aria-labelledby="navbarProfileDropdown">
                        <li><a href="<?php echo e(route('profil.show')); ?>" class="text-center d-block text-decoration-none text-white"><h5><?php echo e(Auth::user()->name); ?></h5></a></li>
                        <li><hr class="dropdown-divider"></li>
                        <?php if(Auth::user()->role === 1): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.dashboard')); ?>">Admin Dashboard</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <?php endif; ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('my-articles.index')); ?>">My Articles</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('my-articles.create')); ?>">Create Article</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(route('profil.index')); ?>">Setting</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <button class="dropdown-item" type="submit">Logout</button>
                            </form>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link text-white" href="<?php echo e(route('login')); ?>">Login</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link text-white" href="<?php echo e(route('register')); ?>">Register</a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH D:\Coding\Laravel\paleoatlas-main\resources\views/front/layout/navbar.blade.php ENDPATH**/ ?>