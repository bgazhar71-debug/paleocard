<?php $__env->startSection('title', 'All Category - PaleoAtlas'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <div class="alert alert-info py-2">
            Showing all articles with category:
        </div>
        <div class="row">
            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-sm-6 col-md-4 col-lg-3 mb-4">
                    <div class="card h-100 shadow-sm border-0 category-card transition" style="border-radius: 1rem;">
                        <div class="card-body d-flex flex-column justify-content-center align-items-center text-center">
                            <a href="<?php echo e(url('category/'.$item->slug)); ?>" class="text-decoration-none text-dark w-100">
                                <span class="d-block mb-2">
                                    <i class="fas fa-folder fa-4x d-none d-md-inline"></i>
                                    <i class="fas fa-folder fa-2x d-inline d-md-none"></i>
                                </span>
                                <h5 class="card-title mt-2 mb-0"><?php echo e($item->name); ?></h5>
                                <small class="text-muted">(<?php echo e($item->articles_count); ?> articles)</small>
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    </div>
    <style>
        .category-card:hover {
            box-shadow: 0 0.5rem 1.5rem rgba(0,0,0,0.12);
            transform: translateY(-4px) scale(1.03);
            transition: all 0.2s;
        }
        .category-card .fa-folder {
            color: #ffc107;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layout.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\Laravel\paleoatlas-main\resources\views/front/category/all-category.blade.php ENDPATH**/ ?>