<?php $__env->startSection('title', 'Dashboard - Admin'); ?>

<?php $__env->startSection('content'); ?>
    
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
        <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
            <h1 class="h2">Dashboard</h1>
        </div>
        <div class="row">
            <div class="col-6">
                <div class="card text-white bg-primary mb-3" style="max-width: 100%;">
                    <div class="card-header">Total Article</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($total_articles); ?> Article</h5>
                        <p class="card-text">
                            <a href="<?php echo e(url('article')); ?>" class="text-white">View</a>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card text-white bg-secondary mb-3" style="max-width: 100%;">
                    <div class="card-header">Total Category</div>
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($total_categories); ?> Categories</h5>
                        <p class="card-text">
                            <a href="<?php echo e(url('categories')); ?>" class="text-white">View</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-6">
                <h4>Latest Articles</h4>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Views</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $latest_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->Category->name); ?></td>
                                <td><?php echo e($item->views); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('article/'.$item->id)); ?>" class="btn btn-sm btn-secondary">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-6">
                <h4>Popular Articles</h4>
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Views</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $popular_articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->Category->name); ?></td>
                                <td><?php echo e($item->views); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(url('article/'.$item->id)); ?>" class="btn btn-sm btn-secondary">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('back.layout.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\Laravel\paleoatlas-main\resources\views/back/dashboard/index.blade.php ENDPATH**/ ?>