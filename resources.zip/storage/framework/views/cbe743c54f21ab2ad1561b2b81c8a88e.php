<div class="offcanvas-md offcanvas-end bg-body-tertiary" tabindex="-1" id="sidebarMenu" aria-labelledby="sidebarMenuLabel">
    <div class="offcanvas-header">
        <h5 class="offcanvas-title" id="sidebarMenuLabel">Company name</h5>
        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#sidebarMenu" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body d-md-flex flex-column p-0 pt-lg-3 overflow-y-auto">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="<?php echo e(url('/')); ?>">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#"></use>
                    </svg>
                    <h3 style="color: black">Paleo Atlas</h3>

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="<?php echo e(url('dashboard')); ?>">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#house-fill"></use>
                    </svg>
                    Dashboard

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2" href="<?php echo e(url('article')); ?>">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#journals"></use>
                    </svg>
                    Article

                </a>
            </li>

            <?php if(auth()->user()->role == 1): ?>
                <li class="nav-item">
                    <a class="nav-link d-flex align-items-center gap-2" href="<?php echo e(url('categories')); ?>">
                        <svg class="bi" aria-hidden="true">
                            <use xlink:href="#tag"></use>
                        </svg>
                        Categories

                    </a>
                </li>
            <?php endif; ?>

            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2" href="<?php echo e(url('users')); ?>">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#people"></use>
                    </svg>
                    Users

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2" href="<?php echo e(url('config')); ?>">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#database-fill-gear"></use>
                    </svg>
                    Config

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2" href="<?php echo e(url('knowledge')); ?>">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#lightbulb-fill"></use>
                    </svg>
                    Knowledge

                </a>
            </li>
        </ul>
        <hr class="my-3">
        <ul class="nav flex-column mb-auto">
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2" href="#">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#gear-wide-connected"></use>
                    </svg>
                    Settings

                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link d-flex align-items-center gap-2" href="<?php echo e(route('logout')); ?>"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    <svg class="bi" aria-hidden="true">
                        <use xlink:href="#door-closed"></use>
                    </svg>
                    Sign out
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>
    </div>
</div><?php /**PATH D:\Coding\Laravel\paleoatlas-main\resources\views/back/layout/sidebar.blade.php ENDPATH**/ ?>